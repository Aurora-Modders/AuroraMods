This is a pre-installed 32-bit version of C# Aurora v1.00

Create an Aurora directory and copy these files into it. Do NOT place in Program Files.

Run Aurora.exe.

The various images used for flags, race pictures, medals, ships, etc were all found online in an image search. If anyone would like me to remove images or attribute credit, please let me know.